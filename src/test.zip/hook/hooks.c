/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   hooks.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dcasadio <dcasadio@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/12/18 22:00:00 by dcasadio          #+#    #+#             */
/*   Updated: 2026/07/07 18:15:31 by dcasadio         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"
#include "parsing.h"
#include "window.h"
#include "mlx.h"
#include "game.h"

#define MOVE_SPEED 0.1

int	handle_close(t_game *game)
{
	free_struct(game);
	exit(0);
	return (0);
}
 
static void	handle_move(t_map *map, int dx, int dy)
{
	map->p_pos.x += dx * MOVE_SPEED;
	map->p_pos.y += dy * MOVE_SPEED;
	printf("hook handle_move: p_pos=(%.2f, %.2f)\n",
		map->p_pos.x, map->p_pos.y);

	render_walls(0)
}
 
int	handle_keypress(int keycode, t_game *game)
{
	if (keycode == KEY_ESC)
		handle_close(game);
	else if (keycode == KEY_W || keycode == KEY_UP)
		handle_move(game, 0, -1);
	else if (keycode == KEY_S || keycode == KEY_DOWN)
		handle_move(game, 0, 1);
	else if (keycode == KEY_A || keycode == KEY_LEFT)
		handle_move(game, -1, 0);
	else if (keycode == KEY_D || keycode == KEY_RIGHT)
		handle_move(game, 1, 0);
	return (0);
}
